README

NameSayer is a name practicing application developed to help lecturers practice the names of students in their classes.
The application was developed to run on the linux operating system.

Included with this application is a database containing wav files of pre-recorded names. This can be found in the same
folder as the runnable jar file folder named 'Resources'. The data base itself is stored in a folder within called
'Database'. If at any point you wish to replace this database, simply replace this folder with another of the same name
containing the list of wav files you want.


To run this application:

Open terminal and locate the directory NameSayer is located in
Run the command "java -jar NameSayer.jar”.

If the above doesn't work, you can try:

Double click the jar file to launch the application.


For detailed information on how to run/use this application, refer to the user manual provided with the application.


The NameSayer application uses some open source icons. References to these are listed below:

Record button:
https://icons8.com/icon/80424/record

Play button:
https://icons8.com/icon/9978/play

Next button:
https://icons8.com/icon/9990/next-button

Previous button:
https://icons8.com/icon/9985/previous-track

Stop button:
https://png.icons8.com/ios/2x/stop-filled.png

Toggle button:
https://png.icons8.com/ios/2x/replace.png

Microphone button:
https://icons8.com/icon/9622/microphone

Volume button:
https://icons8.com/icon/9983/volume







